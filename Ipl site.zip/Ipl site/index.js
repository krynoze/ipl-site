var matches = [
	{
	"abbreviation": "M1",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M2",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M3",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M4",
	"teamA": "Sun Risers Hyderabad (SRH)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M5",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M6",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M7",
	"teamA": "Sun Risers Hyderabad (SRH)", 
	"teamB": "Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M8",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M9",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M10",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M11",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M12",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M13",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M14",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M15",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M16",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Sunrisers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M17",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M18",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M19",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Delhi Daredevils (DD)"
	},
	{
	"abbreviation": "M20",
	"teamA": "Sun Risers Hyderabad (SRH)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M21",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M22",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M23",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M24",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M25",
	"teamA": "Sun Risers Hyderabad (SRH)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M26",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M27",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M28",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M29",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M30",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M31",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M32",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M33",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M34",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": " Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M35",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M36",
	"teamA": "Sun Risers Hyderabad (SRH)",
	"teamB": "Delhi Capitals (DC)"
	},
	{
	"abbreviation": "M37",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M38",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M39",
	"teamA": "Sun Risers Hyderabad (SRH)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M40",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M41",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M42",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M43",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M44",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M45",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M46",
	"teamA": "Kings XI Punjab (KXIP)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M47",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M48",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M49",
	"teamA": "Chennai Super Kings (CSK)",
	"teamB": " Mumbai Indians (MI)"
	},
	{
	"abbreviation": "M50",
	"teamA": "Kolkata Knight Riders (KKR)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M51",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M52",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Rajasthan Royals (RR)"
	},
	{
	"abbreviation": "M53",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M54",
	"teamA": "Royal Challengers Bangalore (RCB)",
	"teamB": "Sun Risers Hyderabad (SRH)"
	},
	{
	"abbreviation": "M55",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Kolkata Knight Riders (KKR)"
	},
	{
	"abbreviation": "M56",
	"teamA": "Rajasthan Royals (RR)",
	"teamB": "Royal Challengers Bangalore (RCB)"
	},
	{
	"abbreviation": "M57",
	"teamA": "Delhi Capitals (DC)",
	"teamB": "Chennai Super Kings (CSK)"
	},
	{
	"abbreviation": "M58",
	"teamA": "Mumbai Indians (MI)",
	"teamB": "Kings XI Punjab (KXIP)"
	},
	{
	"abbreviation": "M59",
	"teamA":"first",
	"teamB":"fourth"
	},
	{
	"abbreviation": "M60",
	"teamA": "third",
	"teamB": "second"
	},
	{
	"abbreviation": "M61",
	"teamA": "a",
	"teamB": "b"
	},
	{
	"abbreviation": "M62",
	"teamA": "x",
	"teamB": "y"
	}
]

	var dropdown = $('#locality-dropdown');
	var radiovalue1 = $("#team-A");
	var radiovalue2 = $("#team-B");

	// Populate dropdown with list of matches
  $.each(matches, function () {
    dropdown.append($('<option></option>').attr('value', this.abbreviation).text(this.teamA + " " + "vs" + " " + this.teamB).attr('jsondata', JSON.stringify(this)));
  })

  dropdown.on('change', function() {
  	var jsond = $(this).find("option").eq(this.selectedIndex).attr("jsondata")
  	var jsonparsed = JSON.parse(jsond);
  	radiovalue1.text(jsonparsed.teamA);
   	radiovalue2.text(jsonparsed.teamB);
  });

	function getQueryVariable(variable)
	{	
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable)
               		{return pair[1];}
       }
	}
	var name = getQueryVariable("username");
	name += ' ' + 'Please' + ' ' + 'Bet' ;
	document.getElementById("welcome_user").innerText =  name ;

	
  

  